const User =
  require("../models/User");

const Referral =
  require("../models/Referral");




exports.getDashboard =
  async (req, res) => {

  try {

    const user =
      await User.findById(req.user.id);

    const referrals =
      await Referral.find({

        referrer: req.user.id

      })
      .populate(
        "referredUser",
        "username createdAt"
      )
      .sort({ createdAt: -1 });

    // Rank
    const higherUsers =
      await User.countDocuments({

        activeReferralCount: {
          $gt: user.activeReferralCount
        }

      });

    res.json({

      success: true,

      referral_code:
        user.referralCode,

      pending_earnings:
        user.pendingReferralEarnings,

      total_earned:
        user.referralEarnings,

      total_referrals:
        user.totalReferralCount,

      active_referrals:
        user.activeReferralCount,

      rank: higherUsers + 1,

      referrals:
        referrals.map(ref => ({

          username:
            ref.referredUser.username,

          join_date:
            ref.referredUser.createdAt,

          earnings:
            ref.earnings,

          active:
            ref.isActive

        }))

    });

  } catch (err) {

    console.error(err);

    res.status(500).json({

      message:
        "Failed to load dashboard"

    });

  }

};







exports.getLeaderboard = async (req, res) => {
  try {

    const limit =
      parseInt(req.query.limit) || 100;

    const users = await User.find({

      activeReferralCount: { $gt: 0 }

    })
    .sort({

      activeReferralCount: -1,
      referralEarnings: -1

    })
    .limit(limit)
    .select(
      `
      username
      profilePicture
      activeReferralCount
      referralEarnings
      isVerified
      country
      `
    );

    const leaderboard =
  users.map((user, index) => ({

    rank: index + 1,

    user_id: user._id,

    username: user.username,

    avatar:
      user.profilePicture ||
      "/uploads/images/africa.png",

    referrals:
      user.activeReferralCount || 0,

    earnings:
      user.referralEarnings || 0,

    isVerified:
      user.isVerified || false,

    country:
      user.country || ""

  }));

    res.json({

      success: true,

      leaderboard

    });

  } catch (err) {

    console.error(
      "LEADERBOARD ERROR:",
      err
    );

    res.status(500).json({

      success: false,

      message:
        "Failed to load leaderboard"

    });

  }
};
