const Story = require("../models/Story");
const User = require("../models/User");
const { logActivity } = require("./userActivityController");

// ================= CREATE STORY =================
exports.createStory = async (req, res) => {
  try {
    const userId = req.user.id;

    if (!req.file) {
      return res.status(400).json({ message: "No media uploaded" });
    }

    const story = await Story.create({
      user: userId,
      media: req.file.path,
      caption: req.body.caption || "",
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24h
    });

    // ===== LOG POST ACTIVITY =====
    await logActivity(req.user.id, "story", story._id);

    res.status(201).json({ story });
  } catch (err) {
    console.error("CREATE STORY ERROR:", err);
    res.status(500).json({ message: "Failed to create story" });
  }
};

// ================= GET STORIES (FEED STYLE) =================
exports.getStories = async (req, res) => {
  try {
    const userId = req.user.id;

    // Get current user
    const user = await User.findById(userId);

    // Get people you follow + yourself
    const users = [userId, ...(user.following || [])];

    const stories = await Story.find({
      user: { $in: users }
    })
      .populate("user", "username fullName profilePicture isVerified")
      .sort({ createdAt: -1 });

    // Group stories by user
    const grouped = {};

    stories.forEach(story => {
      const uid = story.user._id.toString();

      if (!grouped[uid]) {
        grouped[uid] = {
          user: story.user,
          stories: []
        };
      }

      grouped[uid].stories.push({
  ...story.toObject(),
  isOwner: story.user._id.toString() === userId.toString(), 
      isSeen: story.viewers.some(
    v => v.user.toString() === userId.toString()
        )  
      });
    });

    res.status(200).json({
      stories: Object.values(grouped)
    });

  } catch (err) {
    console.error("GET STORIES ERROR:", err);
    res.status(500).json({ message: "Failed to load stories" });
  }
};

// ================= VIEW STORY =================
exports.viewStory = async (req, res) => {
  try {
    const userId = req.user.id;
    const storyId = req.params.id;

    const story = await Story.findById(storyId);

    if (!story) {
      return res.status(404).json({ message: "Story not found" });
    }

    // Prevent self view
    if (story.user.toString() === userId.toString()) {
      return res.status(200).json({ success: true });
    }

    // Check if already viewed
    const existingViewer = story.viewers.find(
      v => v.user.toString() === userId.toString()
    );

    if (!existingViewer) {
      story.viewers.push({
        user: userId,
        viewedAt: new Date(),
        reacted: null
      });

      await story.save();
      console.log("Viewer added:", userId);
      
      // Log story view activity 
      await logActivity(userId, "story_view", story._id);
    }

    res.status(200).json({ success: true });

  } catch (err) {
    console.error("VIEW STORY ERROR:", err);
    res.status(500).json({ message: "Failed to view story" });
  }
};

// ================= REACT TO STORY =================
exports.reactToStory = async (req, res) => {
  try {
    const userId = req.user.id;
    const storyId = req.params.id;
    const { type } = req.body;

    if (!type) {
      return res.status(400).json({ message: "Reaction type required" });
    }

    const story = await Story.findById(storyId);

    if (!story) {
      return res.status(404).json({ message: "Story not found" });
    }

    if (story.user.toString() === userId.toString()) {
    return res.status(400).json({ message: "You can't react to your own story" });
    }

    // ===============================
    // ENSURE USER IS IN VIEWERS
    // ===============================
    let viewer = story.viewers.find(
      v => v.user.toString() === userId.toString()
    );

    if (!viewer) {
      viewer = {
        user: userId,
        viewedAt: new Date(),
        reacted: null
      };
      story.viewers.push(viewer);
    }

    // ===============================
    // HANDLE REACTION (MAIN ARRAY)
    // ===============================
    const existingReaction = story.reactions.find(
      r => r.user.toString() === userId.toString()
    );

    if (existingReaction) {
      existingReaction.type = type;
    } else {
      story.reactions.push({
        user: userId,
        type
      });
    }

    // ===============================
    // UPDATE VIEWER REACTION 
    // ===============================
    viewer.reacted = type;

    // ===============================
    // SAVE
    // ===============================
    await story.save();

    // log story react activity 
    await logActivity(userId, "story_react", story._id);

    res.status(200).json({
      success: true,
      reactions: story.reactions
    });

  } catch (err) {
    console.error("REACT STORY ERROR:", err);
    res.status(500).json({ message: "Failed to react to story" });
  }
};


// ================= REMOVE REACTION =================
exports.removeReaction = async (req, res) => {
  try {
    const userId = req.user.id;
    const storyId = req.params.id;

    const story = await Story.findById(storyId);

    if (!story) {
      return res.status(404).json({ message: "Story not found" });
    }

    // ===============================
    // REMOVE FROM REACTIONS ARRAY
    // ===============================
    story.reactions = story.reactions.filter(
      r => r.user.toString() !== userId.toString()
    );

    // ===============================
    // CLEAR FROM VIEWERS
    // ===============================
    const viewer = story.viewers.find(
      v => v.user.toString() === userId.toString()
    );

    if (viewer) {
      viewer.reacted = null;
    }

    // ===============================
    // SAVE
    // ===============================
    await story.save();

    // log story delete react activity 
    await logActivity(userId, "story_reaction_removed", story._id);

    res.status(200).json({ success: true });

  } catch (err) {
    console.error("REMOVE REACTION ERROR:", err);
    res.status(500).json({ message: "Failed to remove reaction" });
  }
};



// ================= GET STORY VIEWERS + REACTIONS =================
exports.getStoryViewers = async (req, res) => {
  try {
    const storyId = req.params.id;

    const story = await Story.findById(storyId)
      .populate("viewers.user", "username fullName profilePicture isVerified");

    if (!story) {
      return res.status(404).json({ message: "Story not found" });
    }

    const viewers = story.viewers.map(v => ({
      _id: v.user._id,
      username: v.user.username,
      fullName: v.user.fullName,
      profilePicture: v.user.profilePicture,
      isVerified: v.user.isVerified,
      reaction: v.reacted
    }));

    res.status(200).json({ viewers });

  } catch (err) {
    console.error("GET STORY VIEWERS ERROR:", err);
    res.status(500).json({ message: "Failed to load viewers" });
  }
};
