const Group = require("../models/Group");
const Message = require("../models/Message");
const User = require("../models/User");
const Notification = require("../models/Notification");
const { sendPushNotification } = require("./notificationController");

const POPULATE_SENDER = "fullName username profilePicture isVerified";
const POPULATE_MEMBER = "fullName username profilePicture isVerified country";

function emit(req, room, event, payload) {
  try {
    const io = req.app.get("io");
    if (io && room) io.to(room).emit(event, payload);
  } catch (_) {}
}

function isAdmin(group, userId) {
  return group.admin && group.admin.toString() === userId.toString();
}

function isMember(group, userId) {
  return (group.members || []).some(m => m.toString() === userId.toString());
}

/* ---------- CRUD ---------- */
exports.createGroup = async (req, res) => {
  try {
    const { name, description = "", profilePicture = "", members = [] } = req.body;
    if (!name) return res.status(400).json({ message: "Group name required" });

    const memberSet = new Set([req.user._id.toString(), ...members.map(String)]);
    const group = await Group.create({
      name,
      description,
      profilePicture,
      admin: req.user._id,
      members: [...memberSet],
      inviteCode: Math.random().toString(36).slice(2, 10)
    });
    res.status(201).json(group);
  } catch (err) {
    console.error("CREATE GROUP ERROR:", err);
    res.status(500).json({ message: "Failed to create group" });
  }
};

exports.getGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId)
      .populate("members", POPULATE_MEMBER)
      .populate("admin",   POPULATE_MEMBER);
    if (!group) return res.status(404).json({ message: "Group not found" });
    res.json(group);
  } catch (err) {
    res.status(500).json({ message: "Failed" });
  }
};

// groups the current user belongs to (inbox tab)
exports.listMyGroups = async (req, res) => {
  try {
    const archived = req.query.archived === "1";
    const filter = { members: req.user._id };
    filter[archived ? "archivedBy" : "archivedBy"] = archived
      ? req.user._id
      : { $ne: req.user._id };

    const groups = await Group.find(filter)
      .select("name description profilePicture lastMessage lastMessageAt members admin updatedAt")
      .sort({ lastMessageAt: -1, updatedAt: -1 });

    const formatted = await Promise.all(groups.map(async g => {
      const unreadCount = await Message.countDocuments({
        group: g._id,
        sender: { $ne: req.user._id },
        isRead: false
      });
      return {
        _id: g._id,
        name: g.name,
        description: g.description,
        profilePicture: g.profilePicture,
        lastMessage: g.lastMessage || "",
        updatedAt: g.lastMessageAt || g.updatedAt,
        memberCount: (g.members || []).length,
        unreadCount
      };
    }));
    res.json(formatted);
  } catch (err) {
    console.error("LIST GROUPS ERROR:", err);
    res.status(500).json({ message: "Failed" });
  }
};

exports.updateGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ message: "Not found" });
    if (!isAdmin(group, req.user._id)) return res.status(403).json({ message: "Admin only" });

    const { name, description, profilePicture } = req.body;
    if (name !== undefined)            group.name = name;
    if (description !== undefined)     group.description = description;
    if (profilePicture !== undefined)  group.profilePicture = profilePicture;
    await group.save();
    emit(req, `group:${group._id}`, "group:updated", group);
    res.json(group);
  } catch (err) { res.status(500).json({ message: "Failed" }); }
};

exports.deleteGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ message: "Not found" });
    if (!isAdmin(group, req.user._id)) return res.status(403).json({ message: "Admin only" });
    await Message.deleteMany({ group: group._id });
    await Group.deleteOne({ _id: group._id });
    emit(req, `group:${group._id}`, "group:deleted", { _id: group._id });
    res.json({ success: true });
  } catch (err) { res.status(500).json({ message: "Failed" }); }
};

/* ---------- members ---------- */
exports.getMembers = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId).populate("members", POPULATE_MEMBER);
    if (!group) return res.status(404).json({ message: "Not found" });
    res.json({ admin: group.admin, members: group.members });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};

exports.addMembers = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ message: "Not found" });
    if (!isAdmin(group, req.user._id)) return res.status(403).json({ message: "Admin only" });

    const incoming = Array.isArray(req.body.members) ? req.body.members
                   : req.body.userId ? [req.body.userId]
                   : [];
    incoming.forEach(id => {
      if (!group.members.map(String).includes(String(id))) group.members.push(id);
    });
    await group.save();
    emit(req, `group:${group._id}`, "group:updated", group);
    res.json(group);
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};

exports.removeMember = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ message: "Not found" });
    if (!isAdmin(group, req.user._id)) return res.status(403).json({ message: "Admin only" });
    group.members = group.members.filter(m => m.toString() !== req.params.memberId);
    await group.save();
    emit(req, `group:${group._id}`, "group:updated", group);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};

exports.leaveGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ message: "Not found" });
    group.members = group.members.filter(m => m.toString() !== req.user._id.toString());
    // if admin leaves, hand it to the next member
    if (isAdmin(group, req.user._id) && group.members.length) {
      group.admin = group.members[0];
    }
    if (!group.members.length) {
      await Message.deleteMany({ group: group._id });
      await Group.deleteOne({ _id: group._id });
      emit(req, `group:${group._id}`, "group:deleted", { _id: group._id });
      return res.json({ success: true, deleted: true });
    }
    await group.save();
    emit(req, `group:${group._id}`, "group:updated", group);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};

/* ---------- group photo upload ---------- */
exports.updateGroupPhoto = async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ message: "No file" });
    const group = await Group.findById(req.params.groupId);
    if (!group) return res.status(404).json({ message: "Not found" });
    if (!isAdmin(group, req.user._id)) return res.status(403).json({ message: "Admin only" });
    group.profilePicture = req.file.path || req.file.secure_url || req.file.url;
    await group.save();
    emit(req, `group:${group._id}`, "group:updated", group);
    res.json({ profilePicture: group.profilePicture });
  } catch (e) {
    console.error("GROUP PHOTO ERROR:", e);
    res.status(500).json({ message: "Failed" });
  }
};

/* ---------- archive / clear ---------- */
exports.archiveGroup = async (req, res) => {
  try {
    await Group.updateOne({ _id: req.params.groupId }, { $addToSet: { archivedBy: req.user._id } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};
exports.unarchiveGroup = async (req, res) => {
  try {
    await Group.updateOne({ _id: req.params.groupId }, { $pull: { archivedBy: req.user._id } });
    res.json({ success: true });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};
exports.clearGroup = async (req, res) => {
  try {
    const id = req.params.groupId;
    await Group.updateOne(
      { _id: id, "clearedBy.user": { $ne: req.user._id } },
      { $push: { clearedBy: { user: req.user._id, at: new Date() } } }
    );
    await Group.updateOne(
      { _id: id, "clearedBy.user": req.user._id },
      { $set: { "clearedBy.$.at": new Date() } }
    );
    res.json({ success: true });
  } catch (e) { res.status(500).json({ message: "Failed" }); }
};

/* ---------- messages ---------- */
exports.sendGroupMessage = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);
    if (!group)                          return res.status(404).json({ message: "Group not found" });
    if (!isMember(group, req.user._id))  return res.status(403).json({ message: "Not a member" });

    const { text = "", media = "", type = "text", voiceDuration = "", replyTo } = req.body;
    if (!text && !media) return res.status(400).json({ message: "Empty message" });

    let message = await Message.create({
      group: group._id,
      sender: req.user._id,
      text, media, type, voiceDuration,
      replyTo: replyTo || null
    });

    message = await Message.findById(message._id)
      .populate("sender", POPULATE_SENDER)
      .populate("replyTo");

    const preview = text || (type === "image" ? "📷 Photo"
                          : type === "video"  ? "🎬 Video"
                          : type === "voice"  ? "🎙️ Voice"
                          : type === "document" ? "📎 Document"
                          : "Message");

    group.lastMessage   = preview;
    group.lastMessageAt = new Date();
    group.archivedBy    = [];
    await group.save();

    emit(req, `group:${group._id}`, "message:new", message);
    res.status(201).json(message);
  } catch (err) {
    console.error("GROUP SEND ERROR:", err);
    res.status(500).json({ message: "Failed" });
  }
};

exports.getGroupMessages = async (req, res) => {
  try {
    const groupId = req.params.groupId;
    const page  = Math.max(parseInt(req.query.page  || "1", 10), 1);
    const limit = Math.min(parseInt(req.query.limit || "30", 10), 100);

    const group = await Group.findById(groupId).select("clearedBy");
    let cutoff = null;
    if (group && Array.isArray(group.clearedBy)) {
      const mine = group.clearedBy.find(c => c.user && c.user.toString() === req.user._id.toString());
      if (mine) cutoff = mine.at;
    }

    const filter = { group: groupId };
    if (cutoff) filter.createdAt = { $gt: cutoff };

    const total = await Message.countDocuments(filter);
    const messages = await Message.find(filter)
      .populate("sender", POPULATE_SENDER)
      .populate("replyTo")
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(limit);

    res.json({ messages: messages.reverse(), page, hasMore: page * limit < total });
  } catch (err) {
    res.status(500).json({ message: "Failed" });
  }
};
