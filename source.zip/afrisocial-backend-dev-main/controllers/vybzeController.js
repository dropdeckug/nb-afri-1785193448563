const Post = require("../models/Post");
const Comment = require("../models/Comment");
const User = require("../models/User");




exports.getVybzeFeed = async (req, res) => {
  try {
    let userId = null;
    let followingIds = [];
    let interests = [];
    let behaviorPreferences = {};

    // ===============================
    // GET USER (IF LOGGED IN)
    // ===============================
    if (req.user) {
      userId = req.user._id;

      const currentUser = await User.findById(userId)
        .select("following interests feedPreferences");

      followingIds = currentUser?.following || [];
      interests = currentUser?.interests || [];
      behaviorPreferences = currentUser?.feedPreferences || {};
    }

    // ===============================
    // FETCH VIDEOS (ALWAYS EXCLUDE OWN)
    // ===============================
    let query = {
      video: { $exists: true, $ne: null },
      createdAt: {
        $gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
      }
    };

    // ALWAYS exclude own videos if user exists
    if (userId) {
      query.user = { $ne: userId };
    }

    let videos = await Post.find(query)
      .sort({ createdAt: -1 })
      .limit(500)
      .populate("user", "fullName username profilePicture isVerified country followers")
      .populate("mentions", "username fullName profilePicture"); 

    // ===============================
   // FETCH SPONSORED VIDEOS
   // ===============================
     const sponsoredVideos = await Post.find({
    isSponsored: true,

    video: { $exists: true, $ne: null },

    $or: [
    { expiresAt: null },
    { expiresAt: { $gt: new Date() } }
    ]
   })
   .sort({ createdAt: -1 })
   .limit(30)
   .populate(
   "user",
   "fullName username profilePicture isVerified country followers"
   )
   .populate(
   "mentions",
  "username fullName profilePicture"
  );

 // RANDOM ROTATION
  const shuffledSponsored = sponsoredVideos.sort(
  () => 0.5 - Math.random()
  );

    // ===============================
    // SCORE VIDEOS
    // ===============================
    const scoredVideos = await Promise.all(
      videos.map(async (video) => {
        let score = 0;

        const likes = video.likes?.length || 0;
        const stars = video.stars?.length || 0;
        const views = video.views || 0;

        const commentCount = await Comment.countDocuments({ post: video._id });

        const hoursAgo =
          (Date.now() - new Date(video.createdAt)) / (1000 * 60 * 60);

        // FOLLOWING BOOST
        if (
          userId &&
          followingIds.some(id => id.toString() === video.user._id.toString())
        ) {
          score += 15;
        }

        // ===============================
      // INTEREST + BEHAVIOR MATCH
     // ===============================
      if (
      userId &&
      video.hashtags &&
      video.hashtags.length > 0
      ) {

   video.hashtags.forEach(tag => {

  if (interests.includes(tag)) {
    score += 8;
  }

  const behaviorScore =
    behaviorPreferences.get(tag) || 0;

  score += behaviorScore * 2.5;

   });

  }

        // ENGAGEMENT
        score += likes * 1.2;
        score += stars * 1.5;
        score += commentCount * 1.5;
        score += views * 0.6;

        if (views > 1000) score += 20;
        if (views > 5000) score += 40;
        if (views > 10000) score += 60;

        // ===============================
       // LIGHT FRESHNESS BOOST
      // ===============================
      if (hoursAgo < 1) score += 10;
      else if (hoursAgo < 6) score += 6;
      else if (hoursAgo < 24) score += 3;
      else if (hoursAgo < 72) score += 1;

        // ===============================
       // UNSEEN VIDEO BOOST
      // ===============================
      const hasSeen =
      video.viewedBy?.some(
      id => id.toString() === userId?.toString()
      );

      if (hasSeen) {
      score -= 150;
      } else {
       score += 35;
     }

        // SMALL CREATOR BOOST
        const followerCount = video.user.followers?.length || 0;
        if (followerCount < 500) {
          score += (500 - followerCount) / 20;
        }

        // RANDOM BOOST
        score += Math.random() * 20;

        // EXTRA RANDOM FOR GUESTS
        if (!userId) {
        score += Math.random() * 25;
       }

        // TIME DECAY
        score -= hoursAgo * 0.2;

        return {
          ...video.toObject(),
          commentCount,
          score
        };
      })
    );

    // ===============================
    // SORT
    // ===============================
    scoredVideos.sort((a, b) => b.score - a.score);

 // ===============================
// REMOVE HEAVILY WATCHED VIDEOS
// ===============================
const filteredScoredVideos = scoredVideos.filter(video => {

  const hasSeen =
    video.viewedBy?.some(
      id => id.toString() === userId?.toString()
    );

  // Keep unseen videos
  if (!hasSeen) return true;

  // 10% chance for old watched videos to reappear
  return Math.random() < 0.10;
}); 

    // ===============================
    // DIVERSITY
    // ===============================
    const creatorCount = {};
    const finalFeed = [];

    for (let video of filteredScoredVideos) {
      const uid = video.user._id.toString();
      creatorCount[uid] = creatorCount[uid] || 0;

      if (creatorCount[uid] < 2) {
        finalFeed.push(video);
        creatorCount[uid]++;
      }
    }

// ===============================
// DISCOVERY + SPONSORED MIX
// ===============================
const shuffled = [...finalFeed].sort(
  () => 0.5 - Math.random()
);

let mixedFeed = [];

let randomIndex = 0;
let sponsoredIndex = 0;

finalFeed.forEach((video, i) => {

  // NORMAL VIDEO
  mixedFeed.push(video);

  // RANDOM DISCOVERY VIDEO
  if (i % 5 === 0 && shuffled[randomIndex]) {

    mixedFeed.push(shuffled[randomIndex]);

    randomIndex++;
  }

  // ===============================
// SMART RANDOM SPONSORED INSERTION
// ===============================
const shouldInsertSponsored =

  // random chance
  Math.random() < 0.28 &&

  // sponsored exists
  shuffledSponsored.length > 0 &&

  // avoid back-to-back ads
  mixedFeed[mixedFeed.length - 1]?.type !== "sponsored";

if (shouldInsertSponsored) {

  const sponsored =
    shuffledSponsored[
      sponsoredIndex % shuffledSponsored.length
    ];

  if (sponsored && sponsored.user) {

    mixedFeed.push({
      ...sponsored.toObject(),
      type: "sponsored"
    });

    sponsoredIndex++;
  }
}
});

// ===============================
// FINAL SAFETY FILTER
// ===============================
const safeFeed = mixedFeed.filter(video => {

  if (!video || !video.user) return false;

  // DON'T hide sponsored videos
  if (video.type === "sponsored") {
    return true;
  }

  if (!userId) return true;

  return (
    video.user._id.toString() !== userId.toString()
  );
});

res.status(200).json({
  videos: safeFeed
});

  } catch (error) {
    console.error("Vybze feed error:", error);
    res.status(500).json({ message: "Failed to load Vybze feed" });
  }
};






exports.getSingleVideo = async (req, res) => {
  try {
    const { videoId } = req.params;

    const video = await Post.findById(videoId)
      .populate("user", "fullName username profilePicture isVerified country followers")
      .populate("mentions", "username fullName profilePicture");

    if (!video || !video.video) {
      return res.status(404).json({ message: "Video not found" });
    }

    // Count comments
    const commentCount = await Comment.countDocuments({ post: video._id });

    // Optional: check if current user liked/starred
    let isLiked = false;
    let isStarred = false;

    if (req.user) {
      const userId = req.user._id.toString();

      isLiked = video.likes?.some(id => id.toString() === userId);
      isStarred = video.stars?.some(id => id.toString() === userId);
    }

    res.status(200).json({
      video: {
        ...video.toObject(),
        commentCount,
        isLiked,
        isStarred
      }
    });

  } catch (error) {
    console.error("Get video error:", error);
    res.status(500).json({ message: "Failed to load video" });
  }
};
