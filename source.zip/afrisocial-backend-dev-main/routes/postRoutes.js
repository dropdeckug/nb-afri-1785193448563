const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const postController = require("../controllers/postController");
const commentController = require("../controllers/commentController");
const upload = require("../middleware/upload");
const optionalAuth = require("../middleware/optionalAuth");


// Ceate post
router.post("/", auth, upload.array("media", 6), postController.createPost); // max 6 images or 1 video

//  public feed
router.get("/feed", auth, postController.getFeed);

// Feed video views
router.post("/:postId/view", auth, postController.addVideoView);

// User posts
router.get("/user/:userId", postController.getPostsByUser);

// Post action button
router.post("/:id/like", auth, postController.likePost);
router.post("/:id/star", auth, postController.starPost);

// Get single post by ID
router.get("/:postId", postController.getSinglePost);

// Get all comment for a post 
router.get("/:postId/comments", commentController.getCommentsByPost);

// Delete post
router.delete(
  "/:id",
  auth,
  postController.deletePost
);

router.get(
  "/hashtag/:tag",
  auth,
  postController.getPostsByHashtag
);


router.post(
  "/:id/impression",
  auth,
  postController.trackImpression
);

router.post(
  "/:id/click",
  auth,
  postController.trackClick
);


module.exports = router;





