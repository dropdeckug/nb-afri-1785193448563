const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const upload = require("../middleware/upload");


const {
  createStory,
  getStories,
  viewStory, 
  reactToStory, 
  removeReaction, 
  getStoryViewers
} = require("../controllers/storyController");

// Create story
router.post("/", auth, upload.single("media"), createStory);

// Get stories
router.get("/", auth, getStories);

// View story
router.post("/:id/view", auth, viewStory);

// react to story 
router.post("/react/:id", auth, reactToStory);

// delete reaction 
router.delete("/react/:id", auth, removeReaction);

// get story viewers 
router.get("/:id/viewers", auth, getStoryViewers);

module.exports = router;
