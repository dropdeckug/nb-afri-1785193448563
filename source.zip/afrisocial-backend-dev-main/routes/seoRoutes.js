const express = require("express");

const router = express.Router();

const Post = require("../models/Post");

const User = require("../models/User");


// =======================================
// POST SEO ROUTE
// =======================================

router.get("/p/:postId", async (req, res) => {

  try {

    const post = await Post.findById(
      req.params.postId
    ).populate("user");

    if (!post) {

      return res
        .status(404)
        .send("Post not found");

    }

    // ===================================
    // PREVIEW IMAGE
    // ===================================

    let previewImage = "";

    // IMAGE POST
    if (
      post.images &&
      post.images.length > 0
    ) {

      previewImage = post.images[0];

    }

    // VIDEO POST
    else if (post.videoThumbnail) {

      previewImage =
        post.videoThumbnail;

    }

    // FALLBACK
    else {

      previewImage =
        post.user.profilePicture
        || "/uploads/images/africa.png";

    }

    const image =
      previewImage.startsWith("http")
      ? previewImage
      : `https://www.afrisocial.com.ng${previewImage}`;

    // ===================================
    // DESCRIPTION
    // ===================================

    const description =
      post.text?.slice(0, 180)
      || "See this post on Afrisocial";

    // ===================================
    // TITLE
    // ===================================

    const title =
      post.text?.slice(0, 60)
      || `${post.user.fullName} on Afrisocial`;

    // ===================================
    // RESPONSE
    // ===================================

    res.send(`

      <!DOCTYPE html>

      <html>

      <head>

        <title>
          ${title}
        </title>

        <meta charset="UTF-8" />

        <meta
          property="og:title"
          content="${title}"
        />

        <meta
          property="og:description"
          content="${description}"
        />

        <meta
          property="og:image"
          content="${image}"
        />

        <meta
          property="og:type"
          content="article"
        />

        <meta
          property="og:url"
          content="https://www.afrisocial.com.ng/p/${post._id}"
        />

        <meta
          name="twitter:card"
          content="summary_large_image"
        />

        <meta
          name="twitter:title"
          content="${title}"
        />

        <meta
          name="twitter:description"
          content="${description}"
        />

        <meta
          name="twitter:image"
          content="${image}"
        />

      </head>

      <body>

        <script>

          window.location =
          "/view-post.html?postId=${post._id}";

        </script>

      </body>

      </html>

    `);

  } catch (err) {

    console.error(err);

    res.status(500).send("Server error");

  }

});


// =======================================
// PROFILE SEO ROUTE
// =======================================

router.get("/u/:username", async (req, res) => {

  try {

    const user = await User.findOne({

      username:
      req.params.username.toLowerCase()

    });

    if (!user) {

      return res
        .status(404)
        .send("User not found");

    }

    const profileImage =
      user.profilePicture?.startsWith("http")

      ? user.profilePicture

      : `https://www.afrisocial.com.ng${user.profilePicture}`;

    res.send(`

      <!DOCTYPE html>

      <html>

      <head>

        <title>
          ${user.fullName} (@${user.username})
        </title>

        <meta charset="UTF-8" />

        <meta
          property="og:title"
          content="${user.fullName} on Afrisocial"
        />

        <meta
          property="og:description"
          content="${
            user.bio ||
            "See profile on Afrisocial"
          }"
        />

        <meta
          property="og:image"
          content="${profileImage}"
        />

        <meta
          property="og:type"
          content="profile"
        />

        <meta
          property="og:url"
          content="https://www.afrisocial.com.ng/u/${user.username}"
        />

        <meta
          name="twitter:card"
          content="summary_large_image"
        />

        <meta
          name="twitter:title"
          content="${user.fullName} on Afrisocial"
        />

        <meta
          name="twitter:description"
          content="${
            user.bio ||
            "See profile on Afrisocial"
          }"
        />

        <meta
          name="twitter:image"
          content="${profileImage}"
        />

      </head>

      <body>

        <script>

          window.location =
          "/profile.html?userId=${user._id}";

        </script>

      </body>

      </html>

    `);

  } catch (err) {

    console.error(err);

    res.status(500).send("Server error");

  }

});

// =======================================
// VYBZE VIDEO SEO ROUTE
// =======================================

router.get("/v/:videoId", async (req, res) => {

  try {

    const video =
      await Post.findById(req.params.videoId)
      .populate("user");

    if (!video || !video.video) {

      return res
      .status(404)
      .send("Video not found");

    }

    const rawImage =
      video.videoThumbnail
      || video.images?.[0]
      || video.user.profilePicture
      || "/uploads/images/africa.png";

    const image =
      rawImage.startsWith("http")
      ? rawImage
      : `https://www.afrisocial.com.ng${rawImage}`;

    const description =
      video.text?.slice(0, 180)
      || "Watch this video on Afrisocial";

    res.send(`

<!DOCTYPE html>

<html>

<head>

<title>
${video.user.fullName} on Afrisocial Vybze
</title>

<meta charset="UTF-8" />

<meta
property="og:title"
content="${video.user.fullName} on Afrisocial Vybze"
/>

<meta
property="og:description"
content="${description}"
/>

<meta
property="og:image"
content="${image}"
/>

<meta
property="og:type"
content="video.other"
/>

<meta
property="og:url"
content="https://www.afrisocial.com.ng/v/${video._id}"
/>

<meta
property="og:site_name"
content="Afrisocial"
/>

<meta
name="twitter:card"
content="summary_large_image"
/>

<meta
name="twitter:image"
content="${image}"
/>

</head>

<body>

<script>

window.location =
"/vybze-player.html?videoId=${video._id}";

</script>

</body>

</html>

`);

  } catch (err) {

    console.error(err);

    res.status(500).send("Server error");

  }

});

// =======================================
// TEST ROUTE
// =======================================

router.get("/testseo", (req, res) => {

  res.send("SEO WORKING");

});


module.exports = router;
