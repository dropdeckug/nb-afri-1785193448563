const express = require("express");
const router = express.Router();
const protect = require("../middleware/auth");
const pollController = require("../controllers/pollController");
const upload = require("../middleware/upload"); // multer

router.post("/", protect, upload.any(), pollController.createPoll);
router.post("/:id/vote", protect, pollController.votePoll);
router.post("/:id/respond", protect, upload.single("media"), pollController.respondPoll);
router.post("/:pollId/react", protect, pollController.reactToPoll);
router.get('/:pollId/voters/:optionId', protect, pollController.getPollVoters);
router.get('/:pollId/responses', protect, pollController.getPollResponses);
router.get("/user/:userId", protect, pollController.getPollsByUser);


module.exports = router;
