const express = require("express");
const router = express.Router();

const Post = require("../models/Post");
const User = require("../models/User");

router.get("/sitemap.xml", async (req, res) => {
  try {

    const posts = await Post.find({})
      .select("_id createdAt updatedAt images videoThumbnail");

    const users = await User.find({})
      .select("username createdAt updatedAt profilePicture");

    let urls = "";

    // ====================================
    // POSTS
    // ====================================

    posts.forEach(post => {

      const lastMod =
        post.updatedAt ||
        post.createdAt ||
        new Date();

      let imageXml = "";

      // Index ALL images
      if (
        Array.isArray(post.images) &&
        post.images.length > 0
      ) {

        post.images.forEach(img => {

          if (img) {

            imageXml += `
<image:image>
  <image:loc>${img}</image:loc>
</image:image>`;

          }

        });

      }

      // If no images, use video thumbnail
      else if (post.videoThumbnail) {

        imageXml += `
<image:image>
  <image:loc>${post.videoThumbnail}</image:loc>
</image:image>`;

      }

      urls += `
<url>
  <loc>https://www.afrisocial.com.ng/p/${post._id}</loc>
  <lastmod>${lastMod.toISOString()}</lastmod>
  ${imageXml}
</url>`;

    });

    // ====================================
    // USERS
    // ====================================

    users.forEach(user => {

      const lastMod =
        user.updatedAt ||
        user.createdAt ||
        new Date();

      let imageXml = "";

      if (user.profilePicture) {

        imageXml = `
<image:image>
  <image:loc>${user.profilePicture}</image:loc>
</image:image>`;

      }

      urls += `
<url>
  <loc>https://www.afrisocial.com.ng/u/${user.username}</loc>
  <lastmod>${lastMod.toISOString()}</lastmod>
  ${imageXml}
</url>`;

    });

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset
xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">

${urls}

</urlset>`;

    res.header("Content-Type", "application/xml");
    res.send(xml);

  } catch (err) {

    console.error(err);
    res.status(500).send("Error");

  }
});

module.exports = router;
