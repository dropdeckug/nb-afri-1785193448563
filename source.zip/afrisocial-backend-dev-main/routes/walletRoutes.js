const express = require("express");

const router = express.Router();

const auth =
  require("../middleware/auth");

const adminOnly =
  require("../middleware/adminOnly");

const {
  getWallet,
  initializeRecharge,
  verifyRecharge,
  withdrawFunds, 
  convertToStars, 
  sendWithdrawCode, 
  sendGift, 
  approveWithdrawal,
  rejectWithdrawal,
  getAllWithdrawals, 
  createWalletPin, 
  sendVybzeGift, 
  sendProfileGift, 
  sendFeedGift
} = require("../controllers/walletController");

router.get(
  "/",
  auth,
  getWallet
);

router.post(
  "/create-pin",
  auth,
  createWalletPin
);

router.post(
  "/recharge/init",
  auth,
  initializeRecharge
);

router.get(
  "/recharge/verify",
  verifyRecharge
);

router.post(
  "/withdraw",
  auth,
  withdrawFunds
);

router.post(
  "/gift",
  auth,
  sendGift
);

router.post(
  "/send-code",
  auth,
  sendWithdrawCode
);

router.post(
  "/convert",
  auth,
  convertToStars
);

router.post(
  "/gift/vybze",
  auth,
  sendVybzeGift
);

router.post(
  "/profile-gift",
  auth,
 sendProfileGift
);

router.post(
"/feed-gift",
auth,
sendFeedGift
);

// ─────────────────────────────
// ADMIN WITHDRAWAL ROUTES
// ─────────────────────────────

router.get(
  "/admin/withdrawals",
  auth,
  adminOnly,
  getAllWithdrawals
);

router.put(
  "/withdraw/approve/:transactionId",
  auth,
  adminOnly,
  approveWithdrawal
);

router.put(
  "/withdraw/reject/:transactionId",
  auth,
  adminOnly,
  rejectWithdrawal
);

module.exports = router;
