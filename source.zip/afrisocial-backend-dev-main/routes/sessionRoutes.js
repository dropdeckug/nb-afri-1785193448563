const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");

const {
  startSession,
  heartbeat,
  endSession
} = require("../controllers/sessionController");

router.post("/start", auth, startSession);
router.post("/heartbeat", auth, heartbeat);
router.post("/end", auth, endSession);

module.exports = router;
