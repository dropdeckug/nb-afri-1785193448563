const multer = require("multer");
const { CloudinaryStorage } = require("multer-storage-cloudinary");
const cloudinary = require("../config/cloudinary");

const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: async (req, file) => {
    const mt = (file.mimetype || "").toLowerCase();
    const isImage = mt.startsWith("image/");
    const isVideo = mt.startsWith("video/");
    const isAudio = mt.startsWith("audio/");

    // Cloudinary stores audio under resource_type "video"
    const resource_type = isImage ? "image" : (isVideo || isAudio) ? "video" : "auto";

    const base = { folder: "afrisocial", resource_type };

    // Only apply width/crop/duration to image+video.  Applying those to a voice
    // note makes Cloudinary reject the upload (500 Internal Server Error).
    if (isImage) {
      base.transformation = [{ quality: "auto", fetch_format: "auto", width: 1280, crop: "limit" }];
      base.allowed_formats = ["jpg", "jpeg", "png", "webp", "gif"];
    } else if (isVideo) {
      base.transformation = [{ quality: "auto", width: 720, crop: "limit", duration: 60 }];
      base.allowed_formats = ["mp4", "mov", "webm", "m4v"];
    } else if (isAudio) {
      base.allowed_formats = ["webm", "mp3", "wav", "ogg", "m4a", "aac"];
    }

    return base;
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 30 * 1024 * 1024 },
});

module.exports = upload;
