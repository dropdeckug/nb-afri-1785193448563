const mongoose = require("mongoose");

const walletTransactionSchema =
  new mongoose.Schema({

    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    type: {
      type: String,
      enum: [
        "recharge",
        "withdraw",
        "gift",
        "convert",
        "referral",
        "earning",
        "promotion",
        "cashout"
      ],
      required: true
    },

    title: String,

    amount: {
      type: Number,
      required: true
    },

    currency: {
      type: String,
      default: "money"
    },

    status: {
      type: String,
      enum: ["pending", "completed", "failed"],
      default: "completed"
    },

    reference: String,

    metadata: {
      type: Object,
      default: {}
    }

  }, { timestamps: true });

module.exports =
  mongoose.model(
    "WalletTransaction",
    walletTransactionSchema
  );
