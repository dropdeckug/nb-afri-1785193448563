const mongoose = require("mongoose");

const userActivitySchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  type: { 
    type: String, 
    enum: ["login", "post", "like", "comment", "view", "gift", "reply", "star", "follow", "message", "like_comment", "story", "story_view", "story_react", "story_reaction_removed"], 
    required: true 
  },
  target: { type: mongoose.Schema.Types.ObjectId }, // e.g., postId, commentId
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("UserActivity", userActivitySchema);
