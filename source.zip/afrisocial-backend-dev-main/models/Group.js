const mongoose = require("mongoose");

const groupSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    profilePicture: { type: String, default: "" },

    admin: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true
    },

    members: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    }],

    inviteCode: { type: String, unique: true, sparse: true },

    lastMessage: { type: String, default: "" },
    lastMessageAt: { type: Date },

    // users who archived / cleared this group from their inbox
    archivedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    clearedBy: [{
      user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      at:   { type: Date, default: Date.now }
    }]
  },
  { timestamps: true }
);

module.exports = mongoose.model("Group", groupSchema);
