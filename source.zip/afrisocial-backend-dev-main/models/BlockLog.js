const mongoose = require('mongoose');
const BlockLogSchema = new mongoose.Schema({
  blocker:   { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  blocked:   { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  reason:    { type: String },
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('BlockLog', BlockLogSchema);
