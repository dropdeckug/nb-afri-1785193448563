const mongoose = require("mongoose");

const pollResponseSchema = new mongoose.Schema({
  poll: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Poll",
    required: true
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },
  text: {
    type: String,
    required: true,
    trim: true
  },
  media: {
    type: String, // image path (since frontend sends images only)
    default: null
  }
}, { timestamps: true });

module.exports = mongoose.model("PollResponse", pollResponseSchema);
