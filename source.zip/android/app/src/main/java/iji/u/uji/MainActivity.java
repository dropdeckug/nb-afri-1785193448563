package iji.u.uji;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
