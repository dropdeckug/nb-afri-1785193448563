// server.js
const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const connectDB = require("./config/db");
const updateLastActive = require("./middleware/updateLastActive");

// ─── ADD REQUIRING SECURITY PACKAGES HERE ────────────────────────────────────
const mongoSanitize = require("express-mongo-sanitize");
const rateLimit = require("express-rate-limit");

// Load environment variables first
dotenv.config();

// Connect to MongoDB
connectDB();

const app = express();

// Middlewares
// CORS allow-list for frontends that are allowed to call this API.
const allowedOrigins = new Set([
  "http://localhost:3000",
  "http://localhost:2435",
  "http://localhost:5173",
  "http://localhost:8080",
  "https://afrisocial.com.ng",
  "https://www.afrisocial.com.ng",
  "https://afrisocial-test.netlify.app", 
  "https://afrisocial.vercel.app", 
  "https://afrisocial.netlify.app",
  "https://afrisocial-backend.onrender.com",
  ...(process.env.FRONTEND_URLS || "")
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean),
]);

const allowedOriginPatterns = [
  /^https?:\/\/localhost(?::\d+)?$/i,
  /^https?:\/\/127\.0\.0\.1(?::\d+)?$/i,
  /^https:\/\/.*\.lovable\.app$/i,
  /^https:\/\/.*\.lovableproject\.com$/i,
  /^https:\/\/.*\.lovable\.dev$/i,
  /^https:\/\/([a-z0-9-]+\.)?afrisocial\.[a-z.]+$/i,
];

function isAllowedOrigin(origin) {
  if (!origin) return true; // curl / native apps / same-origin
  return allowedOrigins.has(origin) || allowedOriginPatterns.some((pattern) => pattern.test(origin));
}

const corsOptions = {
  origin(origin, cb) {
    if (isAllowedOrigin(origin)) return cb(null, true);
    console.warn("CORS blocked:", origin);
    return cb(null, false);
  },
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With", "Accept", "Origin"],
  optionsSuccessStatus: 204,
};
app.use(cors(corsOptions));
app.options(/.*/, cors(corsOptions));


// body parses (only define ones - with limit) 
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// ─── PLUG IN DATA SANITIZATION AND RATE LIMITING ──────────────────────────────

// FIX: Unlock read-only query properties on modern Express setups to prevent "TypeError: Cannot set property query..."
app.use((req, res, next) => {
  if (req.query) {
    Object.defineProperty(req, 'query', {
      value: req.query,
      writable: true,
      configurable: true,
      enumerable: true
    });
  }
  next();
});

// 1. Instantly sanitizes all request inputs against NoSQL operators (wipes $ne, $regex, etc)
app.use(mongoSanitize());

// 2. Setup brute-force and request flood limits
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes window
  max: 10, // Max 10 authentication requests per IP address per window
  message: {
    error: 'Too many requests from this device. Please try again after 15 minutes.'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// 3. Force limits directly onto sensitive routes
app.use("/api/users/login", authLimiter);
app.use("/api/users/signup", authLimiter);
app.use("/api/wallet/send-code", authLimiter); // Protects your OTP/Wallet system from spam too

// ─────────────────────────────────────────────────────────────────────────────

app.use(
  "/uploads/thumbnails",
  express.static("uploads/thumbnails")
);

// last active update
app.use(updateLastActive);

// debug logger 
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Routes
const userRoutes = require("./routes/userRoutes");
app.use("/api/users", userRoutes);

const postRoutes = require("./routes/postRoutes");
app.use("/api/posts", postRoutes);

app.use("/api/messages", require("./routes/messageRoutes"));

app.use("/api/explore", require("./routes/exploreRoutes"));

app.use("/api/comments", require("./routes/commentRoutes"));

app.use("/api/notifications", require("./routes/notificationRoutes"));

app.use("/api/explore/comments", require("./routes/exploreCommentRoutes"));

const storyRoutes = require("./routes/storyRoutes");
app.use("/api/stories", storyRoutes);

const moderationRoutes = require('./routes/moderation');
app.use('/api/moderation', moderationRoutes);

const analyticsRoutes = require("./routes/analyticsRoutes"); // Corrected require layout
app.use("/api/analytics", analyticsRoutes);

const vybzeRoutes = require("./routes/vybzeRoutes");
app.use("/api/vybze", vybzeRoutes);

const feedbackRoutes = require("./routes/feedbackRoutes");
app.use("/api/feedback", feedbackRoutes);

const authRoutes = require('./routes/auth');
app.use('/api/auth', authRoutes);

const waitlistRoutes = require("./routes/waitlistRoutes");
app.use("/api/waitlist", waitlistRoutes);

const pollRoutes = require("./routes/pollRoutes");
app.use("/api/polls", pollRoutes);

app.use(
  "/api/wallet",
  require("./routes/walletRoutes")
);

app.use(
  "/api/referral",
  require("./routes/referralRoutes")
);

const searchRoutes = require("./routes/searchRoutes");
app.use("/api/search", searchRoutes);

const seoRoutes = require("./routes/seoRoutes");
app.use("/", seoRoutes);

const sitemapRoutes = require("./routes/sitemapRoutes");
app.use("/", sitemapRoutes);

const robotsRoutes = require("./routes/robotsRoutes");
app.use("/", robotsRoutes);

// global error handler 
app.use((err, req, res, next) => {
  console.error("GLOBAL ERROR:", err);
  // FIX: Mask internal application stacks from showing up on frontend responses
  res.status(500).json({ message: "An internal server error occurred." });
});

require("./cron/reEngagementCron");
require("./utils/birthdayCron");

// Start server (HTTP + Socket.IO)
const PORT = process.env.PORT || 3000;
const http = require("http");
const server = http.createServer(app);

try {
  const { Server } = require("socket.io");
  const jwt = require("jsonwebtoken");
  const User = require("./models/User");
  const Group = require("./models/Group");

  const io = new Server(server, {
    cors: {
      origin(origin, cb) {
        if (isAllowedOrigin(origin)) return cb(null, true);
        console.warn("Socket.IO CORS blocked:", origin);
        return cb(null, false);
      },
      credentials: true
    },
    pingTimeout: 60000
  });

  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token
                 || (socket.handshake.headers.authorization || "").replace(/^Bearer\s+/i, "");
      if (!token) return next(new Error("No token"));
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      const user = await User.findById(decoded.userId).select("_id fullName username");
      if (!user) return next(new Error("Bad token"));
      socket.userId = user._id.toString();
      socket.user = user;
      next();
    } catch (e) { next(new Error("Unauthorized")); }
  });

  io.on("connection", async (socket) => {
    socket.join(`user:${socket.userId}`);
    try {
      const groups = await Group.find({ members: socket.userId }).select("_id");
      groups.forEach(g => socket.join(`group:${g._id}`));
    } catch (_) {}
    io.emit("presence:online", { userId: socket.userId });

    socket.on("conversation:join",  (id) => id && socket.join(`conversation:${id}`));
    socket.on("conversation:leave", (id) => id && socket.leave(`conversation:${id}`));
    socket.on("group:join",         (id) => id && socket.join(`group:${id}`));
    socket.on("group:leave",        (id) => id && socket.leave(`group:${id}`));

    socket.on("typing:start", ({ conversationId, to }) => {
      if (to) io.to(`user:${to}`).emit("typing:start", { conversationId, from: socket.userId });
    });
    socket.on("typing:stop", ({ conversationId, to }) => {
      if (to) io.to(`user:${to}`).emit("typing:stop", { conversationId, from: socket.userId });
    });

    socket.on("call:invite", ({ to, type, sdp, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:invite", {
        from: socket.userId, fromUser: socket.user, type, sdp, callId
      });
    });
    socket.on("call:answer", ({ to, sdp, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:answer", { from: socket.userId, sdp, callId });
    });
    socket.on("call:ice", ({ to, candidate, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:ice", { from: socket.userId, candidate, callId });
    });
    socket.on("call:reject", ({ to, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:reject", { from: socket.userId, callId });
    });
    socket.on("call:end", ({ to, callId }) => {
      if (to) io.to(`user:${to}`).emit("call:end", { from: socket.userId, callId });
    });

    socket.on("disconnect", () => {
      io.emit("presence:offline", { userId: socket.userId });
    });
  });

  app.set("io", io);
  console.log("[socket.io] real-time enabled");
} catch (e) {
  console.warn("[socket.io] not enabled (install `socket.io`):", e.message);
}

server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
