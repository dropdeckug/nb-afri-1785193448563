// realtime.js — shared Socket.IO client for messaging, typing, read receipts & calls.
// Pages can simply do: const sock = window.realtime.connect();
// Loads socket.io-client lazily via CDN so individual pages need no <script> tag.
(function () {
  const STATE = { socket: null, ready: null };

  function token() {
    return localStorage.getItem("token") || localStorage.getItem("authToken") || "";
  }

  function apiBase() {
    // Same base your message.js / feed.js use.
    return (
      localStorage.getItem("apiBase") ||
      window.API_BASE ||
      "https://afrisocial-backend.onrender.com"
    );
  }

  function loadIoScript() {
    if (window.io) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://cdn.socket.io/4.7.5/socket.io.min.js";
      s.async = true;
      s.onload = resolve;
      s.onerror = () => reject(new Error("socket.io-client failed to load"));
      document.head.appendChild(s);
    });
  }

  async function connect() {
    if (STATE.socket && STATE.socket.connected) return STATE.socket;
    if (STATE.ready) return STATE.ready;

    STATE.ready = (async () => {
      const t = token();
      if (!t) return null;
      await loadIoScript();
      const s = window.io(apiBase(), {
        auth: { token: t },
        transports: ["websocket", "polling"],
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000
      });
      STATE.socket = s;

      s.on("connect_error", (e) => console.warn("[realtime] connect_error:", e.message));
      s.on("disconnect", (r)  => console.log("[realtime] disconnect:", r));
      s.on("connect",    ()   => console.log("[realtime] connected"));

      return s;
    })();

    return STATE.ready;
  }

  function on(event, handler) {
    connect().then((s) => s && s.on(event, handler));
    return () => STATE.socket && STATE.socket.off(event, handler);
  }

  function emit(event, payload) {
    connect().then((s) => s && s.emit(event, payload));
  }

  function joinConversation(id) { id && emit("conversation:join", id); }
  function leaveConversation(id){ id && emit("conversation:leave", id); }
  function joinGroup(id)        { id && emit("group:join", id); }
  function leaveGroup(id)       { id && emit("group:leave", id); }

  window.realtime = { connect, on, emit, joinConversation, leaveConversation, joinGroup, leaveGroup };

  // Auto-connect once the page has a token so unread badges etc. start receiving live updates.
  document.addEventListener("DOMContentLoaded", () => { token() && connect(); });
})();
